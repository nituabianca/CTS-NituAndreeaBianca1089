package cerinta3Observer;

public interface Observer {
	void primesteAnunt(String Anunt);
}
