package cerinta1SimpleFactory;

public enum TipBilet {
	BUSINESS,
	ECONOMIC

}
