package cerinta1SimpleFactory;

public interface Bilete {
	public void descriereBilet();
}
