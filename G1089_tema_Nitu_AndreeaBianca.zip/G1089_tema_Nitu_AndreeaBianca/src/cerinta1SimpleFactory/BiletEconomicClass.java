package cerinta1SimpleFactory;

public class BiletEconomicClass implements Bilete {
	@Override
	public void descriereBilet() {
		System.out.println("Biletul ales este de tip Economic Class");
		
	}
}
