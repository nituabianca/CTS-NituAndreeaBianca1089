package cerinta2Proxy;

public interface Rezervare {
	void anuleazaRezervare();
}
